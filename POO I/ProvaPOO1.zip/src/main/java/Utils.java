import java.util.Scanner;

public class Utils {
  private static Scanner scanner = new Scanner(System.in);

  // Função para printar uma linha com quebra de linha
  public static void println(String message) {
    System.out.println(message);
  }
  
  // Função para printar uma linha sem quebra de linha
  public static void print(String message) {
    System.out.print(message);
  }

  // 1. Função para ler uma string do teclado
  public static String readString(String prompt) {
    System.out.print(prompt);
    return scanner.nextLine();
  }

  // 2. Função para ler um número inteiro do teclado
  public static int readInt(String prompt) {
    int value = 0;
    boolean isValid = false;
    while (!isValid) {
      try {
        System.out.print(prompt);
        value = Integer.parseInt(scanner.nextLine());
        isValid = true;
      } catch (NumberFormatException e) {
        System.out.println("Entrada inválida. Por favor, insira um número inteiro.");
      }
    }
    return value;
  }

  // 3. Função para ler um número de ponto flutuante do teclado
  public static double readDouble(String prompt) {
    double value = 0.0;
    boolean isValid = false;
    while (!isValid) {
      try {
        System.out.print(prompt);
        value = Double.parseDouble(scanner.nextLine());
        isValid = true;
      } catch (NumberFormatException e) {
        System.out.println("Entrada inválida. Por favor, insira um número decimal.");
      }
    }
    return value;
  }

  // 4. Função para limpar a tela (simula limpeza no terminal)
  public static void clearScreen() {
    try {
      if (System.getProperty("os.name").contains("Windows")) {
        new ProcessBuilder("cmd", "/c", "cls").inheritIO().start().waitFor();
      } else {
        System.out.print("\033[H\033[2J");
        System.out.flush();
      }
    } catch (Exception e) {
      System.out.println("Erro ao tentar limpar a tela.");
    }
  }

  // 5. Função para pausar o programa até que o usuário pressione Enter
  public static void pause() {
    System.out.println("Pressione Enter para continuar...");
    scanner.nextLine();
  }

  // 6. Função para validar sim ou não do usuário
  public static boolean confirm(String prompt) {
    String input = "";
    while (!input.equalsIgnoreCase("s") && !input.equalsIgnoreCase("n")) {
      System.out.print(prompt + " (s/n): ");
      input = scanner.nextLine();
    }
    return input.equalsIgnoreCase("s");
  }
  
  // 7. Função para esperar a entrada do usuário antes de limpar a tela
  public static void waitClearScreen() {
    System.out.print("\nPressione Enter para continuar...");
    scanner.nextLine(); // Espera o usuário pressionar Enter
    clearScreen(); // Limpa a ---tela
  }
}
