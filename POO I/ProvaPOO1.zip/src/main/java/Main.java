import java.util.ArrayList;
import java.util.Random;

public class Main {
  public static void main(String[] args) {
    Random random = new Random();
    ArrayList<Object> objAnimals = new ArrayList<Object>();
    objAnimals.add(new Dog("Rex", "Labrador", 3));
    if (objAnimals.get(0) instanceof Dog) {
      Dog dog = (Dog) objAnimals.get(0);
      System.out.println("Dog's name: " + dog.getNome());
      dog.animalSound();
    }
    ArrayList<Animal> animais = new ArrayList<Animal>();
    animais.add(new Dog("Rex", "Labrador", random.nextInt(10)));
    animais.add(new Cat("Whiskers", "Siamese", random.nextInt(10)));
    animais.add(new Cow("Moo", "Cow", random.nextInt(10)));
    int opcao = 0;
    int aux;
    while (opcao != 5) {
      Utils.waitClearScreen();
      Utils.println("1 - Cadastrar animal");
      Utils.println("2 - Listar animais");
      Utils.println("3 - Remover animal");
      Utils.println("4 - Barulho dos animais");
      Utils.println("5 - Sair");
      opcao = Utils.readInt("Opção: ");
      switch (opcao) {
        case 1:
          Utils.waitClearScreen();
          String nome = Utils.readString("Nome: ");
          String raca = Utils.readString("Raça: ");
          int idade = Utils.readInt("Idade: ");
          int tipo = Utils.readInt("Tipo de animal (1 - Cachorro, 2 - Gato, 3 - Vaca): ");
          if (tipo == 1) animais.add(new Dog(nome, raca, idade));
          else if (tipo == 2) animais.add(new Cat(nome, raca, idade));
          else if (tipo == 3) animais.add(new Cow(nome, raca, idade));
          else Utils.println("Tipo de animal inválido!");
          break;
        case 2:
          Utils.waitClearScreen();
          aux = 0;
          for (Animal animal : animais) {
            Utils.println(animal.toString());
            aux = 1;
          }
          if (aux == 0) Utils.println("\nNenhum animal cadastrado!");
          break;
        case 3:
          Utils.waitClearScreen();
          String nomeRemover = Utils.readString("Nome: ");
          aux = 0;
          for (int i = 0; i < animais.size(); i++) {
            if (animais.get(i).getNome().equals(nomeRemover)) {
              animais.remove(i);
              aux = i;
              break;
            }
          }
          if (aux == 0) Utils.println("\nAnimal não encontrado!");
          else Utils.println("\nAnimal removido com sucesso!");
          break;
        case 4:
          Utils.waitClearScreen();
          aux = 0;
          for (Animal animal : animais) {
            Utils.print(animal.getNome() + " faz: ");
            boolean dorme = random.nextBoolean();
            animal.animalSound();
            Utils.print("\n");
            if (dorme == true) {
              Utils.print(animal.getNome() + " está cansado: ");
              animal.sleep();
              Utils.print("\n");
            }
            aux = 1;
          }
          if (aux == 0) Utils.println("\nNenhum animal cadastrado!");
          break;
        case 5:
          Utils.waitClearScreen();
          Utils.println("Saindo...");
          break;
      }
    }
  }
}