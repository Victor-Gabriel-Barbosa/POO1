abstract class Animal {
  private String nome, raca;
  private int idade;
  public Animal(String nome, String raca, int idade) {
    if (nome != null) this.nome = nome;
    if (raca != null) this.raca = raca;
    if (idade >= 0) this.idade = idade;
  }
  public String getNome() {
    return nome;
  }
  public String getRaca() {
    return raca;
  }
  public int getIdade() {
    return idade;
  }
  public int setNome(String nome) {
    if (nome == null) return 0;
    this.nome = nome;
    return 1;
  }
  public int setRaca(String raca) {
    if (raca == null) return 0;
    this.raca = raca;
    return 1;
  }
  public int setIdade(int idade) {
    if (idade < 0) return 0;
    this.idade = idade;
    return 1;
  }
  public abstract void animalSound();
  public void sleep() {
    System.out.println("Zzz");
  }
  @Override
  public String toString() {
    return "Nome: " + nome + ", Raça: " + raca + ", Idade: " + idade;
  }
}

class Dog extends Animal {
  public Dog(String nome, String raca, int idade) {
    super(nome, raca, idade);
  }
  public void animalSound() {
    System.out.println("Woof");
  }
}

class Cat extends Animal {
  public Cat(String nome, String raca, int idade) {
    super(nome, raca, idade);
  }
  public void animalSound() {
    System.out.println("Meow");
  }
}

class Cow extends Animal {
  public Cow(String nome, String raca, int idade) {
    super(nome, raca, idade);
  }
  public void animalSound() {
    System.out.println("Moo");
  }
}